<?php
session_start();

require_once "Conexion.php";

// Sólo aceptamos POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: login.php");
    exit;
}

// 1. Recibir y limpiar datos
 $email      = trim($_POST['email']      ?? '');
 $contrasenia = $_POST['contrasenia']    ?? '';

// 2. Validar que no vengan vacíos
if (empty($email) || empty($contrasenia)) {
    header("Location: login.php?error=campos_vacios");
    exit;
}

// 3. Buscar el usuario en la BD (activo = 1)
try {
    $conexion = new Conexion();
    $pdo = $conexion->getConexion();

    $sql = "SELECT id, nombre, email, contrasenia, rol, activo 
            FROM usuario 
            WHERE email = :email 
            LIMIT 1";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([':email' => $email]);
    $usuario = $stmt->fetch();

    // 4. Verificar existencia y estado de cuenta
    if (!$usuario || (int)$usuario['activo'] !== 1) {
        header("Location: login.php?error=no_existe");
        exit;
    }

    // 5. Verificar contraseña (hash bcrypt)
    if (password_verify($contrasenia, $usuario['contrasenia'])) {
        // Login correcto: armamos la sesión
        session_regenerate_id(true);
        $_SESSION['usuario'] = [
            'id'     => $usuario['id'],
            'nombre' => $usuario['nombre'],
            'email'  => $usuario['email'],
            'rol'    => $usuario['rol']
        ];

        // Redirigir según el rol (puedes ajustar las rutas)
        if ($usuario['rol'] === 'admin') {
            header("Location: index.html");
        } else {
            header("Location: portal-paciente.html");
        }
        exit;
    } else {
        // Contraseña incorrecta
        header("Location: login.php?error=contrasenia_incorrecta");
        exit;
    }

} catch (PDOException $e) {
    // En producción loguea $e->getMessage(); no lo muestres al usuario
    header("Location: login.php?error=servidor");
    exit;
}